package com.vaibhav.notesapp.DataModel;

public class TextData {

    private String TextData;

    public String getTextData() {
        return TextData;
    }

    public void setTextData(String textData) {
        TextData = textData;
    }

    public TextData(String textData) {
        TextData = textData;
    }

    public TextData(){

    }
}
